console.log("Welcome to GiggleLab Home!");
